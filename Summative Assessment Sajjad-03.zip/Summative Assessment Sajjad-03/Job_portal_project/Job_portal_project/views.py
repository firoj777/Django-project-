from django.shortcuts import redirect, render
from JobApp.models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import check_password
from django.contrib.auth import update_session_auth_hash

def signinpage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return redirect('index')
        else:
            return redirect('signinpage')
    return render(request, 'signinpage.html')

def signuppage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        user_type = request.POST.get('user_type')
        city = request.POST.get('city')
        gender = request.POST.get('gender')
        email = request.POST.get('email')
        image = request.FILES.get('image')
        
        if password==confirm_password:
            user = custom_user.objects.create_user(
                username=username,
                password=password,
                user_type=user_type,
                city=city,
                gender=gender,
                email=email,
                image=image,
            )
            user.save()
            return redirect('signinpage')
        
    return render(request, 'signuppage.html')

@login_required
def index(request):
    return render(request, 'index.html')

def logoutpage(request):
    logout(request)
    return redirect('signinpage')

@login_required
def addjob(request):
    if request.method == 'POST':
        company_title = request.POST.get('company_title')
        company_description = request.POST.get('company_description')
        company_name = request.POST.get('company_name')
        company_location = request.POST.get('company_location')
        qualification = request.POST.get('qualification')
        deadline = request.POST.get('deadline')
        salary = request.POST.get('salary')
        company_logo = request.FILES.get('company_logo')
        
        adjob= addjob_Model(
            company_title=company_title,
            company_description=company_description,
            company_name=company_name,
            company_location=company_location,
            qualification=qualification,
            deadline=deadline,
            salary=salary,
            company_logo=company_logo,
        )
        adjob.save()
        return redirect('viewlist')
    return render(request, 'addjob.html')


def viewlist(request):
    vfile = addjob_Model.objects.all()
    vdict = {
        'data':vfile
    }
    return render(request, 'viewlist.html', vdict)
@login_required
def deletepage(request, myid):
    addjob_Model.objects.get(id=myid).delete()
    return redirect('viewlist')
@login_required
def viewpage(request, myid):
    vfile = addjob_Model.objects.filter(id=myid)
    vdict = {
        'data':vfile
    }
    return render(request, 'viewpage.html', vdict)
@login_required
def editjobpage(request, myid):
    vfile = addjob_Model.objects.filter(id=myid)
    vdict = {
        'data':vfile
    }
    return render(request, 'editjobpage.html', vdict)
@login_required
def updatepage(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        company_title = request.POST.get('company_title')
        company_description = request.POST.get('company_description')
        company_name = request.POST.get('company_name')
        company_location = request.POST.get('company_location')
        qualification = request.POST.get('qualification')
        deadline = request.POST.get('deadline')
        salary = request.POST.get('salary')
        company_logo = request.FILES.get('company_logo')
        
        adjob= addjob_Model(
            id=id,
            company_title=company_title,
            company_description=company_description,
            company_name=company_name,
            company_location=company_location,
            qualification=qualification,
            deadline=deadline,
            salary=salary,
            company_logo=company_logo,
        )
        adjob.save()
        return redirect('viewlist')
     
@login_required 
def profile(request):
    return render(request, 'profile.html')

@login_required
def change_pass(request):
    current_user = request.user
    if request.method == 'POST':
        current_pass = request.POST.get('current_pass')
        new_password = request.POST.get('new_password')
        repet_password = request.POST.get('repet_password')
        
        if check_password(current_pass, current_user.password):
            if new_password==repet_password:
                current_user.password=new_password
                current_user.set_password(new_password)
                current_user.save()
                update_session_auth_hash(request, current_user)
                return redirect('profile')
        
    return render(request, 'change_pass.html')

