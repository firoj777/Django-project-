from django.contrib import admin

# Register your models here.
from JobApp.models import *

class customs_user(admin.ModelAdmin):
    list_display = ('username', 'user_type')
    
admin.site.register(custom_user,customs_user)
admin.site.register(addjob_Model)
admin.site.register(RecruiterModel)
admin.site.register(SeekerModel)