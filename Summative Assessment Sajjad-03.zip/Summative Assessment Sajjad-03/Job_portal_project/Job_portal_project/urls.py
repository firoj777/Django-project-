"""
URL configuration for Job_portal_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Job_portal_project.views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', signinpage, name='signinpage'),
    path('signuppage/', signuppage, name='signuppage'),
    path('index/', index, name='index'),
    path('logoutpage/', logoutpage, name='logoutpage'),
    path('addjob/', addjob, name='addjob'),
    path('viewlist/', viewlist, name='viewlist'),
    path('deletepage/<str:myid>', deletepage, name='deletepage'),
    path('viewpage/<str:myid>', viewpage, name='viewpage'),
    path('editjobpage/<str:myid>', editjobpage, name='editjobpage'),
    path('updatepage/', updatepage, name='updatepage'),
    path('profile/', profile, name='profile'),
    path('change_pass/', change_pass, name='change_pass'),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
