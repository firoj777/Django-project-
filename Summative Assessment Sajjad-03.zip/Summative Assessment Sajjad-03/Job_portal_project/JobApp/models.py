from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser

class custom_user(AbstractUser):
    user_type = [
        ('Recruiter','Recruiter'),
        ('Seeker','Seeker'),
    ]
    gender = [
        ('Male','Male'),
        ('Female','Female'),
    ]
    user_type = models.CharField(choices=user_type, max_length=100, null=True)
    gender = models.CharField(choices=gender, max_length=100, null=True)
    city = models.CharField(max_length=100, null=True)
    image = models.ImageField(upload_to='media/user')
    
    
class addjob_Model(models.Model):
    company_title = models.CharField(max_length=100, null=True)
    company_description = models.CharField(max_length=100, null=True)
    company_name = models.CharField(max_length=100, null=True)
    company_location = models.CharField(max_length=100, null=True)
    qualification = models.CharField(max_length=100, null=True)
    deadline = models.CharField(max_length=100, null=True)
    salary = models.CharField(max_length=100, null=True)
    company_logo = models.ImageField(upload_to='media/addjob')
    def __str__(self):
        return self.company_name
    
class RecruiterModel(models.Model):
    user = models.OneToOneField(custom_user, on_delete=models.CASCADE, related_name='recruitermodel')
    r_name = models.CharField(max_length=100, null=True)
    adress = models.CharField(max_length=100, null=True)
    location = models.CharField(max_length=100, null=True)
    mobile = models.CharField(max_length=100, null=True)
    
class SeekerModel(models.Model):
    user = models.OneToOneField(custom_user, on_delete=models.CASCADE, related_name='seekermodel')
    s_name = models.CharField(max_length=100, null=True)
    last_degre = models.CharField(max_length=100, null=True)
    pas_year = models.CharField(max_length=100, null=True)
    varsity_name = models.CharField(max_length=100, null=True)
    skill = models.CharField(max_length=100, null=True)
    experience_year = models.CharField(max_length=100, null=True)